/**
 * Integration smoke test: spins up two socket.io-client connections against
 * a locally running instance of the chat server and exercises the core
 * event flow: username set, channel join, message send/receive, typing
 * indicator, reactions, and channel creation.
 */
const { io } = require('socket.io-client');

const URL = 'http://localhost:3000';
let passed = 0;
let failed = 0;

function assert(condition, label) {
  if (condition) {
    passed++;
    console.log(`PASS: ${label}`);
  } else {
    failed++;
    console.log(`FAIL: ${label}`);
  }
}

async function run() {
  const alice = io(URL, { transports: ['websocket'] });
  const bob = io(URL, { transports: ['websocket'] });

  await Promise.all([
    new Promise((res) => alice.on('connect', res)),
    new Promise((res) => bob.on('connect', res)),
  ]);
  assert(alice.connected && bob.connected, 'Both clients connected');

  // --- Username setting ---
  const aliceNamed = new Promise((res) => alice.once('username_set', res));
  alice.emit('set_username', { username: 'Alice' });
  const aliceNameResult = await aliceNamed;
  assert(aliceNameResult.username === 'Alice', 'Alice username set correctly');

  const bobNamed = new Promise((res) => bob.once('username_set', res));
  bob.emit('set_username', { username: 'Bob' });
  await bobNamed;

  // --- Duplicate username rejection ---
  const dupRejected = new Promise((res) => bob.once('username_error', res));
  bob.emit('set_username', { username: 'Alice' });
  const dupResult = await dupRejected;
  assert(/already in use/i.test(dupResult.message), 'Duplicate username rejected');
  // restore Bob's name
  bob.emit('set_username', { username: 'Bob' });
  await new Promise((res) => bob.once('username_set', res));

  // --- Join channel ---
  const aliceHistory = new Promise((res) => alice.once('channel_history', res));
  alice.emit('join_channel', { channelId: 'general' });
  await aliceHistory;

  const bobHistory = new Promise((res) => bob.once('channel_history', res));
  bob.emit('join_channel', { channelId: 'general' });
  await bobHistory;
  assert(true, 'Both clients joined #general');

  // --- Send message, verify other client receives it ---
  const bobReceivesMsg = new Promise((res) => bob.once('new_message', res));
  alice.emit('send_message', { text: 'Hello Bob!', channel: 'general' });
  const msg = await bobReceivesMsg;
  assert(msg.text === 'Hello Bob!' && msg.username === 'Alice', 'Message delivered with correct content/sender');
  assert(typeof msg.timestamp === 'number', 'Message has a timestamp');

  // --- XSS sanitization check ---
  const bobReceivesXss = new Promise((res) => bob.once('new_message', res));
  alice.emit('send_message', { text: '<script>alert(1)</script>Hi', channel: 'general' });
  const xssMsg = await bobReceivesXss;
  assert(!xssMsg.text.includes('<script>'), 'HTML tags stripped from message text');

  // --- Typing indicator ---
  const bobSeesTyping = new Promise((res) => bob.once('typing_update', res));
  alice.emit('typing', { channel: 'general', isTyping: true });
  const typingResult = await bobSeesTyping;
  assert(typingResult.usernames.includes('Alice'), 'Typing indicator shows Alice typing');

  alice.emit('typing', { channel: 'general', isTyping: false });
  await new Promise((res) => setTimeout(res, 200));

  // --- Reactions ---
  const bobSeesReaction = new Promise((res) => bob.once('reaction_update', res));
  bob.emit('add_reaction', { channel: 'general', messageId: msg.id, emoji: '👍' });
  const reactionResult = await bobSeesReaction;
  assert(
    reactionResult.reactions['👍'] && reactionResult.reactions['👍'].includes('Bob'),
    'Reaction added and broadcast correctly'
  );

  // --- Channel creation ---
  const channelCreated = new Promise((res) => alice.once('channel_created', res));
  alice.emit('create_channel', { name: 'Test Channel' });
  const newChannel = await channelCreated;
  assert(newChannel.channel.id === 'test-channel', 'New channel created with correct slug');

  // --- Rate limiting (send > 12 messages quickly) ---
  let rateLimitHit = false;
  alice.on('error_message', (e) => {
    if (/too quickly/i.test(e.message)) rateLimitHit = true;
  });
  for (let i = 0; i < 16; i++) {
    alice.emit('send_message', { text: `spam ${i}`, channel: 'general' });
  }
  await new Promise((res) => setTimeout(res, 300));
  assert(rateLimitHit, 'Rate limiter triggers after rapid messages');

  // --- Disconnect triggers system message + user count update ---
  const aliceSeesLeave = new Promise((res) => alice.once('new_message', (m) => {
    if (m.system && /disconnected/i.test(m.text)) res(m);
  }));
  bob.disconnect();
  const leaveMsg = await aliceSeesLeave;
  assert(/Bob disconnected/.test(leaveMsg.text), 'Disconnect produces system message');

  alice.disconnect();

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed > 0 ? 1 : 0);
}

run().catch((err) => {
  console.error('Test run crashed:', err);
  process.exit(1);
});
